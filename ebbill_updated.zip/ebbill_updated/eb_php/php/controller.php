<?php
require_once 'model.php';

$controller = new controller();

class controller {

public $model;

public function __construct() {

    $this->model = new model();
    
    $url = explode("/", parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
    $endpointUrl = array_pop($url);

    if ($endpointUrl == "insert_validation") {

        $this -> insert_validation();

    } else if ($endpointUrl == "select_validation") {

        $this -> select_validation();

    } else {

        $failed = array('status' => "Failed", "msg" => "url doesn't match");
        exit(json_encode($failed));
    }

}

public function  insert_validation(){

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_POST)) {
        $this->_request = json_decode(file_get_contents('php://input'), true);
    } else{
        $this->_request = $_POST;
    }
 
    $consumer_name = $this->_request['consumer_name'];
    $address_line1= $this->_request['Address_line1'];
    $address_line2 = $this->_request['Address_line2'];
    $address_line3 = $this->_request['Address_line3'];
    $units= $this->_request['units'];
  
    if (isset($consumer_name) && isset($address_line1) && isset($address_line2) && isset($address_line3) && isset($units)){

    $this->model -> insert_function($consumer_name,$address_line1,$address_line2,$address_line3,$units);
    }
    else {
        $error = array(
            'status' => "Failed",
            "msg" => "Invalid Request Parameters."
        );
        exit(json_encode($error));
    }
}
public function select_validation(){

    $this->model-> select_function();
    exit;

}
}
?>