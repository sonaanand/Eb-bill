<?php
$dbhost = "localhost";
$username = "root";
$password = "";
$dbname="stock_management";

$conn=mysqli_connect($dbhost,$username,$password,$dbname);

// connection
if(!$conn){
    die("failed:".mysqli_connect_error());
}else{
    return 'database connected';
}
?>