<?php

require_once 'dbconnect.php';

class model {

    public function insert_function($consumer_name, $address_line1,$address_line2,$address_line3, $units){

        global $conn;
       
        $insert = "INSERT INTO eb_task(consumer_name, Address_line1,Address_line2, Address_line3,units)
        VALUES('$consumer_name','$address_line1','$address_line2','$address_line3',' $units')";
        $sql = mysqli_query($conn, $insert);
echo $sql;

        if (!$sql) {
            $error = array('status' => "Failed", "msg" => "No records created");
        } else {
            $error = array('status' => "Success", "msg" => "New record created successfully");
        }
        exit(json_encode($error));

    }

    public function select_function() {
        global $conn;

       
        $select = "SELECT * FROM eb_task";
        $result = mysqli_query($conn, $select) or die('error');
        $num_of_rows1 = mysqli_num_rows($result);

        if ($num_of_rows1 > 0) {

            while ($row = mysqli_fetch_array($result)) {

                // echo "Total Rows is ". $row['count(*)'];

                $consumer_name = $row['consumer_name'];
                $Address_line1 = $row['Address_line1'];
                $Address_line2 = $row['Address_line2'];
                $Address_line3 = $row['Address_line3'];
                $units = $row['units'];
               

                $return_arr[] = array("consumer_name" => $consumer_name,
                    "Address_line1" => $Address_line1,
                    "Address_line2" => $Address_line2,
                    "Address_line3" => $Address_line3,
                    "units" => $units);

            }
            exit(json_encode($return_arr));

        } else {

            $failed = array('status' => "Failed", "msg" => "No records found in db");
            exit(json_encode($failed));

        }
    }
}
?>