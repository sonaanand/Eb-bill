import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EbformComponent } from './ebform/ebform.component';
import { EblistComponent } from './eblist/eblist.component';

const routes: Routes = [
  {path:'ebform',component:EbformComponent},
  {path:'eblist',component:EblistComponent},
  {path: '',component:EbformComponent,pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
