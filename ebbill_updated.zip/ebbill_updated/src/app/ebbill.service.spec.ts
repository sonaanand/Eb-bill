import { TestBed } from '@angular/core/testing';

import { EbbillService } from './ebbill.service';

describe('EbbillService', () => {
  let service: EbbillService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EbbillService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
