import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class EbbillService {


  constructor(public http: HttpClient) { }
  data: any;

  // post call
  insert(data: object) {
    const headers = { 'content-type': 'application/json' }
    const body = JSON.stringify(data);
    this.http.post("http://localhost/21-12-2021/eb_bill/eb_php/php/controller.php/insert_validation", body, {
      headers, responseType: 'text'
    }).subscribe((res) => {
      alert('New Data inserted')
    }, (error: any) => console.error(error));

  }
// view data
  getdata(data: any) {
    this.data = data;
    console.log(this.data);
  }
  senddata() {
    return this.data;
  }
  // get call
  getall() {
    return this.http.get("http://localhost/21-12-2021/eb_bill/eb_php/php/controller.php/select_validation")
  }

  // calculation
  getunits(units: any) {
    this.units = units;
  }
  units: any;
  Bill: any;
  cal() {
    var unit = this.units;
    if (unit <=100) {
      this.Bill = unit * 0
    } else if (unit <=500) {
      this.Bill = 100 * 0 + (unit - 100) * 5
    }
    else if (unit <=1000) {
      this.Bill = 100 * 0 + 400 * 5 + (unit - 500) * 10
    }
    else if (unit >=1000) {
      this.Bill = 100 * 0 + 400 * 5 + 600 * 10 + (unit - 500) * 15
    }
    console.log(this.Bill);
  }
}
