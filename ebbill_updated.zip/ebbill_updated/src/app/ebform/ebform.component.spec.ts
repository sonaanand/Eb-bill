import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EbformComponent } from './ebform.component';

describe('EbformComponent', () => {
  let component: EbformComponent;
  let fixture: ComponentFixture<EbformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EbformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EbformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
