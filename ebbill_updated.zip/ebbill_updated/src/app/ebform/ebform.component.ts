import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, } from '@angular/forms';
import { Router } from '@angular/router';
import { EbbillService } from '../ebbill.service';

@Component({
  selector: 'app-ebform',
  templateUrl: './ebform.component.html',
  styleUrls: ['./ebform.component.css']
})
export class EbformComponent implements OnInit {

  MyForm!: FormGroup
 

  constructor(private Fb: FormBuilder,public eb:EbbillService,public router:Router) { }

  ngOnInit(): void {
    this.MyForm = new FormGroup({
      consumer_name: this.Fb.control(''),
      Address_line1: this.Fb.control(''),
      Address_line2: this.Fb.control(''),
      Address_line3: this.Fb.control(''),
      units: this.Fb.control(''),

    });
  }
  // validation

  consumer_name = "";
  consumer_nameErr: any = "";

  c_name() {
    var consu_regex = /^[a-zA-Z]+$/;
    var consumer_name = this.consumer_name;
    if (consumer_name == "") {
      this.consumer_nameErr = 'Please enter the consumer name';
    } else if (!consumer_name.match(consu_regex)) {
      this.consumer_nameErr = 'Please valid name';
    } else {
      this.consumer_nameErr = " ";
    }
  }

  Address_line1= "";
  AddressErr: any = "";

  c_addressline1() {
    var Address_line1 = this.Address_line1;
    var Address_regex = /^[1-9]\d*(?: ?(?:[a-z]|[/-] ?\d+[a-z]?))?$/;
    if (Address_line1 == "") {
      this.AddressErr = 'Please enter the consumer Address';
    } else if (!Address_line1.match(Address_regex)) {
      this.AddressErr = 'Please valid house number';
    } else {
      this.AddressErr = " ";
    }
  }
  Address_line2 = "";

  c_addressline2() {
    var Address_line2 = this.Address_line2;
    var Address_regex = /^[a-zA-Z]+$/;
    if (Address_line2 == "") {
      this.AddressErr = 'Please enter the consumer Address';
    }else if (!Address_line2.match(Address_regex)) {
      this.AddressErr = 'Please enter valid place';
    } else {
      this.AddressErr = " ";
    }
  }
  Address_line3 = "";

  c_addressline3() {
    var Address_regex = /^[1-9]\d*$/;
    var Address_line3 = this.Address_line3;
    if (Address_line3 == "") {
      this.AddressErr = 'Please enter the consumer Address';
    } else if (!Address_line3.match(Address_regex)) {
      this.AddressErr = 'Please enter valid pincode';
    } else if(Address_line3.length<6){
      this.AddressErr = 'Please enter 6 digit pincode';
    }else {
      this.AddressErr = " ";
    }
  }
  units = "";
  unitsErr: any = "";

  c_unit(){
    var units = this.units;
    var unit_regex =/^[1-9]\d*$/;
    if (units == "") {
      this.unitsErr = 'Please enter the units';  
    } else if (!units.match(unit_regex)) {
      this.AddressErr = 'Please valid place';
    }else {
      this.unitsErr = " ";
      this.eb.getunits(this.units);
    }
  }

  validate() {
    this.c_name();
    this.c_addressline1();
    this.c_addressline2();
    this.c_addressline3();
    this.c_unit();
    this.send_data();
  }
 
  send_data() {
    if (this.consumer_name && this.Address_line1 && this.Address_line2 && this.Address_line3 && this.units) {
      this.eb.insert(this.MyForm.value);
      this.eb.getdata(this.MyForm.value);
      this.MyForm.reset();
      this.router.navigate(['/eblist/']);

    }else{
      alert('fill all details')
    }
  }
}
