import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EblistComponent } from './eblist.component';

describe('EblistComponent', () => {
  let component: EblistComponent;
  let fixture: ComponentFixture<EblistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EblistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EblistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
