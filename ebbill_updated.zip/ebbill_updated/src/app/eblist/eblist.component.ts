import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { EbbillService } from '../ebbill.service';


@Component({
  selector: 'app-eblist',
  templateUrl: './eblist.component.html',
  styleUrls: ['./eblist.component.css']
})
export class EblistComponent implements OnInit {
  ebbill: any = [];
  dtTrigger: Subject<any> = new Subject<any>();
  // Bill: any;
  Form: any;
  units: any;
  data: any;
  constructor(public eb: EbbillService, public http: HttpClient, public datepipe: DatePipe) { }

  // date
  toDate: Date = new Date();
  some: Date = new Date();
  
  ngOnInit(): void {

    var numberOfDaysToAdd = 15;
    var result = this.some.setDate(this.some.getDate() + numberOfDaysToAdd);
    console.log(new Date(result));

    // view data
    this.data = this.eb.senddata();

    // calculation
    this.eb.cal();

    // getall
    this.eb.getall()
      .subscribe((ebbill: any) => {
        this.ebbill = ebbill;
        console.log(this.ebbill);
        this.dtTrigger.next(0);
      },
        (error: any) => console.error(error));

  }

}







